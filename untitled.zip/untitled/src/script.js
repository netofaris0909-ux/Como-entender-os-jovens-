<script>

    // Animação de scroll reveal

    const observerOptions = {

        threshold: 0.2,

        rootMargin: '0px 0px -100px 0px'

    };

    const observer = new IntersectionObserver((entries) => {

        entries.forEach(entry => {

            if (entry.isIntersecting) {

                entry.target.style.opacity = '1';

                entry.target.style.transform = 'translateY(0)';

            }

        });

    }, observerOptions);

    // Observar todos os elementos animáveis

    document.addEventListener('DOMContentLoaded', () => {

        const animatedElements = document.querySelectorAll(

            '.stat-card, .review-card, .disease-card, .offer-box'

        );

        

        animatedElements.forEach(el => {

            el.style.opacity = '0';

            el.style.transform = 'translateY(30px)';

            el.style.transition = 'opacity 0.8s ease, transform 0.8s ease';

            observer.observe(el);

        });

        // Efeito de pulso no botão CTA

        const ctaButton = document.querySelector('.cta-button');

        

        setInterval(() => {

            ctaButton.classList.add('animate-pulse');

            setTimeout(() => {

                ctaButton.classList.remove('animate-pulse');

            }, 1000);

        }, 3000);

        // Tracking de clique no CTA

        ctaButton.addEventListener('click', () => {

            console.log('CTA clicado - redirecionando para checkout');

        });

    });

    // Adicionar efeito parallax suave no hero

    window.addEventListener('scroll', () => {

        const scrolled = window.pageYOffset;

        const hero = document.getElementById('hero');

        if (hero) {

            hero.style.transform = `translateY(${scrolled * 0.5}px)`;

        }

    });

</script>